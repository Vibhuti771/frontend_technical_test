export const hello = {
  template: require('./hello.html'),
  controller() {
    this.hello = 'TD Frontend Technical Test';
  }
};
